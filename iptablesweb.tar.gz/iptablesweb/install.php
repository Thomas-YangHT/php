<?php
require_once('classes/adodb/adodb.inc.php');
require_once('classes/language_class.php');
require_once('classes/utility_class.php');
require_once('classes/page_class.php');

$PAGE = new page();
$UTILITY = new utility();
$LANGUAGE = new language();

echo $PAGE->getHeader('Install','IptablesWeb - Install');
if ((int)$_GET['phase']<=0){
	$phase=1;
}
else{
	$phase=$_GET['phase'];
}
?>

<div id="container">
	<table id="header"><tr>
	<td class="center"><?php echo $UTILITY->get_logo('install'); ?></td>
	</tr></table>

	<table id="central">
		<tr><td><h4>Installation</h4><h5>Phase <?php echo $phase; ?></h5>
		<?php
		switch($phase){
			case 2:
				echo '<div style="width:400px; margin:0 auto; text-align:left; border: 1px dotted black; padding:3px; font-size:10px;">Anyone who use this script accept follow conditions:<br><br>
This script is free for non commercial use. [ commercial use of the script means the sale (of any type) or the cession (of any type) of services bound directly or indirectly by it for profit]<br><br>
I don\'t assume any implicit or explicit responsability for possible damage caused by proper or improper use of this and i don\'t assure any type of assistance or support.<br><br>
Anyone who use this script, use it at his completely risk and danger.<br><br>
It\'s absolutely prohibited to delete any reference to the author or to the copyright of the same or to source script\'s web site.<br>Moreover, it\'s absolutely prohibited to distribute this script without authorization of the author.</div>';
				echo '<br><form method="post" action="?phase=3">';
				echo '<input name="check_licence" type="radio" value="yes" style="width:20px; padding:0px; font-size:11px;" />I agree&nbsp;&nbsp;&nbsp;<input name="check_licence" type="radio" value="no" checked style="width:20px; padding:0px; font-size:11px;" />I don\'t agree<br /><br /><input type="submit" name="Submit" value="Next" />';
				echo '</form>';
			break;
			case 3:
				if ($_POST['check_licence']!='yes'){
					echo '<div style="color:red">You must accept the conditions to continue the installation! <a href="javascript: history.go(-1)">Back page</a></div>';
				}
				else{
					if(is_writable('includes/connection_settings.php') && is_writable('includes/path_settings.php') && is_writable('includes/session_settings.php')){
?>
        <br />
        Now you must compile all required (*) fields<br />
        <br />
        <form method="post" action="?phase=4">
<table style="margin: 0 auto; font-size:10px;">
  <tr class="center"><td colspan="2"><h5>General configuration</h5></td></tr>
  <tr>
    <td>Public access * </td>
    <td><select name="public"><option selected="selected" value="1">YES</option><option value="0">NO</option></select></td>
  </tr>
  <tr>
    <td>Default language * </td>
    <td><?php echo $LANGUAGE->languagesList(); ?></td>
  </tr>
  <tr>
    <td>System url * </td>
    <td><input type="text" name="url" value="http://" /></td>
  </tr>
  <tr>

    <td>System email * </td>
    <td><input type="text" name="email" value="" /></td>
  </tr>
  <tr>
    <td>Absolute path * </td>
    <td><input type="text" name="path"  value="<?php echo str_replace('install.php', '', $_SERVER['SCRIPT_FILENAME']); ?>" /></td>
  </tr>
  <tr>
    <td>Crontab password * </td>
    <td><input type="text" name="contrab_permission" value="crontab_passwd" /></td>
  </tr>
  <tr>
    <td>Log saved *</td>
    <td><input type="text" name="log_saved" value="30" /></td>
  </tr>
  <tr class="center"><td colspan="2"><h5>&nbsp;</h5>
      <h5>Database configuration</h5></td>
  </tr>
  <tr>
    <td>Database * </td>
    <td><select name="database"><option selected="selected" value="mysql">mysql</option><option value="postgres">postgres</option><option value="postgres">postgres</option><option value="sqlite">sqlite</option><option value="oci8">oci8</option><option value="postgres">postgres</option><option value="postgres64">postgres64</option><option value="postgres7">postgres7</option><option value="postgres8">postgres8</option></select></td>
  </tr>
  <tr>
    <td>Database host * </td>
    <td><input type="text" name="dbhost"  value="" /></td>
  </tr>
  <tr>
    <td>Database name * </td>
    <td><input type="text" name="dbname"  value="" /></td>
  </tr>
  <tr>
    <td>Create a new Database * </td>
    <td><select name="create_db"><option value="1">YES</option><option value="0">NO</option></select>
    </td>
  </tr>
  <tr>
    <td>Username * </td>
    <td><input type="text" name="user"  value="" /></td>
  </tr>
  <tr>
    <td>Password *</td>
    <td><input type="text" name="password"  value="" /></td>
  </tr>
  <tr>
    <td>Ulogd table *</td>
    <td><input type="text" name="ulogd_table"  value="" /></td>
  </tr>
  <tr class="center"><td colspan="2"><h5>&nbsp;</h5>
      <h5>Session configuration</h5></td></tr>
  <tr>
    <td>Garbage collector time * <br />
      (seconds)</td>
    <td><input type="text" name="gc"  value="1800" /></td>
  </tr>
  <tr>
    <td>Session time * (seconds)<br /> 
      (if 0 the cookie will be <br />
      deleted after closing browser)</td>

    <td><input type="text" name="stl"  value="30000" /></td>
  </tr>
  <tr class="center"><td colspan="2"><h5>&nbsp;</h5>
      <h5>Email configuration</h5>
      </td></tr>
  <tr>
    <td>Type of SMTP * </td>
    <td><select name="send_mail_type"><option selected="selected" value="0">Localhost</option><option value="1">External</option></select></td>
  </tr>
  <tr>

    <td>SMTP server</td>
    <td><input type="text" name="mail_server" value="" /></td>
  </tr>
  <tr>
    <td>Authentication</td>
    <td><select name="mail_auth"><option selected="selected" value="1">YES</option><option value="">NO</option></select></td>
  </tr>

  <tr>
    <td>Username</td>
    <td><input type="text" name="mail_username" value="" /></td>
  </tr>
  <tr>
    <td>Password</td>
    <td><input type="text" name="mail_password" value="" /></td>
  </tr>

  <tr>
    <td colspan="2" class="center"><br /><br /><input type="submit" name="send" value="Save" /></td>
    </tr>
</table>
</form>
<div class="center" style="font-size:10px;"><br />* Mandatory field<br />

<?php
					}
					else{
						echo '<div style="color:red">All files into \'includes\' folder must have chmod 0666! <a href="javascript: history.go(-1)">Back page</a></div>';
					}
				}
			break;
			case 4:
				if(!is_writable('includes/path_settings.php') || !is_writable('includes/connection_settings.php') || !is_writable('includes/session_settings.php')){
					echo '<div style="color:red">All files into \'includes\' folder must have chmod 0666. <a href="javascript: history.go(-1)">Back page</a></div>';
				}
				elseif($_POST['create_db']=='' || $_POST['language']=='' || $_POST['public']=='' || $_POST['contrab_permission']=='' || $_POST['url']=='' || $_POST['path']=='' || $_POST['database']=='' || $_POST['dbhost']=='' || $_POST['user']=='' || $_POST['password']=='' || $_POST['dbname']=='' || $_POST['stl']=='' || $_POST['gc']=='' || $_POST['send_mail_type']==''){
					echo '<div style="color:red">All fields (*) are requires. <a href="javascript: history.go(-1)">Back page</a></div>';
				}
				elseif(!(ereg("^.+@[^\.].*\.[a-z]{2,}$", $_POST['email']))){
					echo '<div style="color:red">The mail must be valid. <a href="javascript: history.go(-1)">Back page</a></div>';
				}
				else{
				
					$DB = NewADOConnection($_POST['database']);
					$_res_db = @$DB->Connect($_POST['dbhost'], $_POST['user'], $_POST['password']);
					if (!$_res_db){
						echo '<div style="color:red">There is a database problem! Check your configuration. <a href="javascript: history.go(-1)">Back page</a></div>';
					}
					else{
						$db_create=true;
						if ($_POST['create_db']=='1'){
							$db_create=$DB->Execute("CREATE DATABASE `".$_POST['dbname']."`");
						}
						unset($_res_db);
						$_res_db = @$DB->Connect($_POST['dbhost'], $_POST['user'], $_POST['password'], $_POST['dbname']);
						
						if ($db_create){
							$DB->Execute("CREATE TABLE IPT_block_groups (  block_id INT(10) NOT NULL,  group_id INT(10) NOT NULL,  PRIMARY KEY(block_id, group_id))");
							
							$DB->Execute("CREATE TABLE IPT_block_iptables (  block_id INT(10) NOT NULL,  iptables_id INT(10) NOT NULL,  PRIMARY KEY(block_id, iptables_id))");
							
							$DB->Execute("CREATE TABLE IPT_block_settings (  id INT(10) NOT NULL AUTO_INCREMENT,  plugin_id INT(10) NOT NULL,  settings MEDIUMTEXT NULL,  PRIMARY KEY(id))");
							
							$DB->Execute("CREATE TABLE IPT_groups (  id INT(10) NOT NULL AUTO_INCREMENT,  name VARCHAR(255) NOT NULL,  description TEXT NULL,  PRIMARY KEY(id))");
							
							$DB->Execute("CREATE TABLE IPT_iptables_variables (  id INT(10) NOT NULL AUTO_INCREMENT,  name VARCHAR(255) NOT NULL,  color VARCHAR(7) NOT NULL,  name_web VARCHAR(255) NOT NULL,  other TEXT NULL,  PRIMARY KEY(id))");
							
							$DB->Execute("CREATE TABLE IPT_ip_history (  user_id INT(10) NOT NULL,  date DATETIME NOT NULL,  state INT(3) NOT NULL,  ip CHAR(15) NOT NULL,  PRIMARY KEY(user_id, date, state))");
							
							$DB->Execute("CREATE TABLE IPT_plugins (  id INT(10) NOT NULL AUTO_INCREMENT,  date DATETIME NOT NULL,  folder VARCHAR(255) NOT NULL,  version VARCHAR(255) NOT NULL,  name VARCHAR(255) NOT NULL,  description TEXT NULL,  other MEDIUMTEXT NULL,  PRIMARY KEY(id))");
							
							$DB->Execute("CREATE TABLE IPT_sessions (  id VARCHAR(32) NOT NULL,  user_id INT(10) NOT NULL,  vars MEDIUMTEXT NULL,  date DATETIME NOT NULL,  PRIMARY KEY(id))");
							
							$DB->Execute("CREATE TABLE IPT_settings (  name VARCHAR(255) NOT NULL,  value VARCHAR(255) NULL,  PRIMARY KEY(name))");
							
							$DB->Execute("CREATE TABLE IPT_users (  id INT(10) NOT NULL AUTO_INCREMENT,  username VARCHAR(20) NOT NULL,  passwd VARCHAR(100) NOT NULL,  privilege INT(1) NULL,  name VARCHAR(60) NULL,  surname VARCHAR(60) NULL,  phone VARCHAR(30) NULL,  fax VARCHAR(30) NULL,  mobile_phone VARCHAR(30) NULL,  email VARCHAR(100) NOT NULL,  language VARCHAR(255) NOT NULL,  city VARCHAR(255) NULL,  nation VARCHAR(255) NULL,  place VARCHAR(255) NULL,  zip_code VARCHAR(255) NULL,  address VARCHAR(255) NULL,  group_id INT(10) NOT NULL,  account INT(1) NULL,  created DATETIME NULL,  PRIMARY KEY(id))");
							
							$DB->Execute("CREATE TABLE IPT_user_blocks (  user_id INT(10) NOT NULL,  block_id INT(10) NOT NULL,  ranking INT(10) NOT NULL,  PRIMARY KEY(user_id, block_id))");
							
							$DB->Execute("INSERT INTO `IPT_settings` VALUES ('language', '')");
							$DB->Execute("INSERT INTO `IPT_settings` VALUES ('public', '')");
							$DB->Execute("INSERT INTO `IPT_settings` VALUES ('send_mail_type', '')");
							$DB->Execute("INSERT INTO `IPT_settings` VALUES ('email', '')");
							$DB->Execute("INSERT INTO `IPT_settings` VALUES ('url', '')");
							$DB->Execute("INSERT INTO `IPT_settings` VALUES ('mail_auth', '')");
							$DB->Execute("INSERT INTO `IPT_settings` VALUES ('mail_server', '')");
							$DB->Execute("INSERT INTO `IPT_settings` VALUES ('mail_username', '')");
							$DB->Execute("INSERT INTO `IPT_settings` VALUES ('mail_password', '')");
							$DB->Execute("INSERT INTO `IPT_settings` VALUES ('contrab_permission', '')");
							$DB->Execute("INSERT INTO `IPT_settings` VALUES ('iptablesweb_version', '2')");
							//End import database

							$DB->Execute("UPDATE `IPT_settings` SET `value`='".$_POST['language']."' WHERE `name`='language'");
							$DB->Execute("UPDATE `IPT_settings` SET `value`='".$_POST['public']."' WHERE `name`='public'");
							$DB->Execute("UPDATE `IPT_settings` SET `value`='".$_POST['contrab_permission']."' WHERE `name`='contrab_permission'");
							$DB->Execute("UPDATE `IPT_settings` SET `value`='".$_POST['email']."' WHERE `name`='email'");
							$DB->Execute("UPDATE `IPT_settings` SET `value`='".$_POST['url']."' WHERE `name`='url'");
							
							$file_path='includes/path_settings.php';
							$content_path="<?php\ndefine('PATH_ABS', '".$_POST['path']."');\ndefine('N_LOG', '".$_POST['log_saved']."');?>";
							$handle=fopen($file_path, "w");
							fwrite($handle, $content_path);
							fclose($handle);		
						
							$file_connection='includes/connection_settings.php';
							$content_connection="<?php\n".'$_type_of_db_server="'.$_POST['database'].'";'."\n".'$_host="'.$_POST['dbhost'].'";'."\n".'$_user="'.$_POST['user'].'";'."\n".'$_password="'.$_POST['password'].'";'."\n".'$_db_name="'.$_POST['dbname'].'";'."\n".'$_ulogd_table="'.$_POST['ulogd_table'].'";'.'?>';
							$handle=fopen($file_connection, "w");
							fwrite($handle, $content_connection);
							fclose($handle);

							$file_session='includes/session_settings.php';
							$content_session="<?php\n".'$_session_time = '.$_POST['stl'].";\n".'$_session_gc_time = '.$_POST['gc'].";\n?>";
							$handle=fopen($file_session, "w");
							fwrite($handle, $content_session);
							fclose($handle);


							$DB->Execute("UPDATE `IPT_settings` SET `value`='".$_POST['cookie']."' WHERE `name`='cookie'");
							$DB->Execute("UPDATE `IPT_settings` SET `value`='".$_POST['send_mail_type']."' WHERE `name`='send_mail_type'");
							$DB->Execute("UPDATE `IPT_settings` SET `value`='".$_POST['mail_server']."' WHERE `name`='mail_server'");
							$DB->Execute("UPDATE `IPT_settings` SET `value`='".$_POST['mail_auth']."' WHERE `name`='mail_auth'");
							$DB->Execute("UPDATE `IPT_settings` SET `value`='".$_POST['mail_username']."' WHERE `name`='mail_username'");
							$DB->Execute("UPDATE `IPT_settings` SET `value`='".$_POST['mail_password']."' WHERE `name`='mail_password'");

							echo '<br />Now you must create a group to contain an admin account<br />';
							
							$DB->Execute("DELETE FROM `IPT_groups`");
							
							?>
							<br />
							<form method="post" action="?phase=5">
							<table style="margin: 0 auto; font-size:10px;">
							  <tr>
								<td>Name * </td>
								<td><input type="text" name="name" value="Admin account" /></td>
							  </tr>
							  <tr>
								<td>Description</td>
								<td><textarea name="description" rows="" cols=""></textarea></td>
							  </tr>
							
							  <tr>
								<td colspan="2"><br /><input type="submit" name="send" value="Save" /></td>
							  </tr>
							</table>
							</form>
							<br />
							<div class="center">* Mandatory field</div>
							<?php

						}
						else{
							echo '<div style="color:red">There is a problem to create the database. <a href="javascript: history.go(-1)">Back page</a></div>';
						}
					}
				}
			break;
			case 5:

				//Include files
				require_once('includes/connection_settings.php');
				require_once('includes/session_settings.php');
				require_once('includes/path_settings.php');

				$DB = NewADOConnection($_type_of_db_server);
				$_res_db = @$DB->Connect($_host, $_user, $_password, $_db_name);
				if (!$_res_db){
					exit('Database problem! Check your configuration');
				}

				if ($_POST['name']==''){
					echo '<div style="color:red">All fields (*) are required. <a href="javascript: history.go(-1)">Back page</a></div>';
				}
				else{
					$group_array=array('name'=>$_POST['name'], 'description'=>$_POST['description']);
					$DB->Execute("INSERT INTO `IPT_groups` (`name`, `description`) VALUES ('".$group_array['name']."', '".$group_array['description']."')");
					
					$DB->Execute("DELETE FROM `IPT_users`");
					
					echo '<br />Now you must create an admin account<br />';
					?>
					
					<br />
					<form method="post" action="?phase=6">
					<table style="margin: 0 auto; font-size:10px;">
					  <tr>
						<td>Name * </td>
						<td><input type="text" name="name" /></td>
					  </tr>
					  <tr>
						<td>Surname * </td>
						<td><input type="text" name="surname" /></td>
					  </tr>
					  <tr>
						<td>Country</td>
						<td><input type="text" name="nation" /></td>
					  </tr>
					  <tr>
						<td>City</td>
						<td><input type="text" name="city" /></td>
					  </tr>
					  <tr>
						<td>District</td>
						<td><input type="text" name="place" /></td>
					  </tr>
					  <tr>
						<td>Post code</td>
						<td><input type="text" name="zip_code" /></td>
					  </tr>
					  <tr>
						<td>Address</td>
						<td><input type="text" name="address" /></td>
					  </tr>
					  <tr>
						<td>Telephone</td>
						<td><input type="text" name="phone" /></td>
					  </tr>
					  <tr>
						<td>Fax</td>
						<td><input type="text" name="fax" /></td>
					  </tr>
					  <tr>
						<td>Mobile</td>
						<td><input type="text" name="mobile_phone" /></td>
					  </tr>
					  <tr>
						<td>Username * </td>
						<td><input type="text" name="username" /></td>
					  </tr>
					  <tr>
						<td>Password * </td>
						<td><input type="text" name="passwd" /></td>
					  </tr>
					  <tr>
						<td>Email * </td>
						<td><input type="text" name="email" /></td>
					  </tr>
					  <tr>
						<td>Language * </td>
						<td><?php echo $LANGUAGE->languagesList(); ?></td>
					  </tr>
					  <tr>
						<td>Group * </td>
						<td><select name="group_id">
						<?php
							$groups=array();
							$rs = & $DB->Execute("SELECT * FROM `IPT_groups`");
							while (!$rs->EOF) {
								$groups=$rs->fields;
								echo '<option value="'.$groups['id'].'">'.htmlspecialchars($groups['name']).'</option>';
								$rs->MoveNext();
							}
						?>
						
						</select></td>
					  </tr>
					  <tr>
						<td colspan="2"><br /><input type="submit" name="send" value="Save" /></td>
					  </tr>
					</table>
					</form>
					
					<?php
				}
			break;
			case 6:
			
				//Include files
				require_once('includes/connection_settings.php');
				require_once('includes/session_settings.php');
				require_once('includes/path_settings.php');

				$DB = NewADOConnection($_type_of_db_server);
				$_res_db = @$DB->Connect($_host, $_user, $_password, $_db_name);
				if (!$_res_db){
					exit('Database problem! Check your configuration');
				}
				
				$user_array=array('username'=>$_POST['username'], 'passwd'=>$_POST['passwd'], 'privilege'=>'2', 'name'=>$_POST['name'], 'surname'=>$_POST['surname'], 'phone'=>$_POST['phone'], 'fax'=>$_POST['fax'], 'mobile_phone'=>$_POST['mobile_phone'], 'email'=>$_POST['email'], 'language'=>$_POST['language'], 'city'=>$_POST['city'], 'nation'=>$_POST['nation'], 'place'=>$_POST['place'], 'zip_code'=>$_POST['zip_code'], 'address'=>$_POST['address'], 'group_id'=>$_POST['group_id'], 'account'=>'1');

				if ($user_array['name']=='' || $user_array['surname']=='' || $user_array['language']=='' || $user_array['privilege']=='' || $user_array['group_id']=='' || $user_array['account']==''){
					echo '<div style="color:red">All fields (*) are required. <a href="javascript: history.go(-1)">Back page</a></div>';
				}
				elseif (strlen($user_array['username'])<5){
					echo '<div style="color:red">The user is mandatory and must have at least 5 characters. <a href="javascript: history.go(-1)">Back page</a></div>';
				}
				elseif (strlen($user_array['passwd'])<5){
					echo '<div style="color:red">The password is mandatory and must have at least 5 characters. <a href="javascript: history.go(-1)">Back page</a></div>';
				}
				elseif(!(ereg("^.+@[^\.].*\.[a-z]{2,}$", $user_array['email']))){
					echo '<div style="color:red">The mail must be valid. <a href="javascript: history.go(-1)">Back page</a></div>';
				}
				else{
					$DB->Execute("INSERT INTO `IPT_users` (`username`, `passwd`, `privilege`, `name`, `surname`, `phone`, `fax`, `mobile_phone`, `email`, `language`, `city`, `nation`, `place`, `zip_code`, `address`, `group_id`, `account`, `created`) VALUES ('".$user_array['username']."', '".md5($user_array['passwd'])."', '".$user_array['privilege']."', '".$user_array['name']."', '".$user_array['surname']."', '".$user_array['phone']."', '".$user_array['fax']."', '".$user_array['mobile_phone']."', '".$user_array['email']."', '".$user_array['language']."', '".$user_array['city']."', '".$user_array['nation']."', '".$user_array['place']."', '".$user_array['zip_code']."', '".$user_array['address']."', '".$user_array['group_id']."', '".$user_array['account']."', NOW())");
					echo '<br />Installation completed; remember to DELETE install.php.<br /><br /><a href="index.php">Go to IptablesWeb</a><br />';
				}
				
			break;
			default:
				echo '<div>Welcome to IptablesWeb installation; if you want go on the installation <a href="?phase=2">click here</a></div>';
		}
		?>
		
		</td></tr>
	</table>
	<div id="footer"><img src="images/php.png" alt="" /> <img src="images/css.gif" alt="" /> <img src="images/xhtml.gif" alt="" /><br /><a href="http://iptablesweb.sourceforge.net">IptablesWeb&copy;</a> 2005-2006 [Gnomix]<br />
  IptablesWeb is Free Software released under the GNU/GPL license.</div>
</div>
<?php
echo $PAGE->getFooter();
?>