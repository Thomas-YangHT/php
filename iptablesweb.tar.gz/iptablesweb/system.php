<?php
require_once('includes/config.php');
if($_GET['key_check']!=md5($SETTING->get_value('contrab_permission'))){
	if($_status != AUTH_LOGGED || $_user_active['privilege']!=ADMIN){
		exit('You can\'t access this page');
	}
}
require_once('interfaces/system/crontab.php');

?>