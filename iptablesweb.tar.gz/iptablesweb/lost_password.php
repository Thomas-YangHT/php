<?php
require_once('includes/config.php');
//Load dictionary
$default_language=$SETTING->get_value('language');
$language_file='lang/'.$default_language.'/dictionary.php';
if (file_exists($language_file)){
	require_once($language_file);
}
else{
	exit('NO Dictionary!');
}

echo $PAGE->getHeader('Recover',$admin[83]);
?>

<form method="post" action="">
  <table id="recover_password">
	<tr><td colspan="2" class="center"><?php echo $UTILITY->get_logo('index.php'); ?></td></tr>
  <?php
  	if($_POST['send']==$admin['83']){
		echo '<tr><td colspan="2"><div class="submit_form">'.$USER->reset_password($_POST['email']).'</div></td></tr>';
	}
  ?>
    <tr>
      <td><?php echo $admin[23]; ?></td><td><input type="text" name="email" /></td>
    </tr>
    <tr>
      <td>&nbsp;</td><td><input type="submit" name="send" value="<?php echo $admin['83']; ?>" /></td>
    </tr>
  </table>
</form>

<?php
echo $PAGE->getFooter();
?>