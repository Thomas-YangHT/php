<?php
require_once('includes/config.php');
$PLUGIN->set_block_order('block_list',base64_decode($_POST['user_id']));
?>