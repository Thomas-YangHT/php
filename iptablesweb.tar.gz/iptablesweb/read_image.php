<?php
if($_GET['extn']=='gif' || $_GET['extn']=='png' || $_GET['extn']=='jpg' || $_GET['extn']=='jpeg'){

	require_once('includes/config.php');
	if($_status != AUTH_LOGGED || !($_user_active['privilege']==ADMIN || $_user_active['privilege']==USER)){
		$_user_id='-1';
	}
	else{
		$_user_id=$_user_active['id'];
	}
	$_block_img=$PLUGIN->get_blocks_array($_user_id);

	$_can_access_img=false;
	foreach($_block_img as $_img_selected){
		if($_img_selected['block_id']==$_GET['image_file']){
			$_can_access_img=true;
		}
	}
	
	if (!$_can_access_img){
		exit('You can\'t access this image');
	}
	else{
		$filename=PATH_ABS.'tmp/'.$_GET['image_file'].'.'.$_GET['extn'];
		if (file_exists($filename)){
			$fp = fopen($filename, 'rb');
			header('Content-Type: image/'.$_GET['extn']);
			header("Content-Length: " . filesize($filename));
			fpassthru($fp);
			fclose($fp);
			exit;
		}
	}
}
exit('No data image');

?>