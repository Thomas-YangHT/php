<?php
require_once('includes/config.php');

if($_status != AUTH_LOGGED || !($_user_active['privilege']==ADMIN || $_user_active['privilege']==USER)){
	header("Refresh: 0;URL=index.php");
	exit();
}

//Load dictionary
$language_file='lang/'.$_user_active['language'].'/dictionary.php';
if (file_exists($language_file)){
	require_once($language_file);
}
else{
	exit('NO Dictionary!');
}

echo $PAGE->getHeader('user',$admin[40]);
?>

<div id="container">
	<table id="header"><tr>
	<td class="left"><?php echo $UTILITY->get_logo('user'); ?></td>
	<td class="right"><h3><?php echo $admin[1].' '.$_user_active['name'].' '.$_user_active['surname']; ?></h3><?php echo $admin[2]; ?>: <?php echo $admin[117]; ?><br />
    <?php echo $admin[3]; ?>: <?php echo $SESSION->last_log(); ?></td>
	</tr></table>

	<table id="central">
		<tr><td id="menu"><a href="user.php"><?php echo $admin[4]; ?></a> | <?php echo $USER->link_interface($_user_active['privilege'], USER); ?><a href="user.php?action=settings"><?php echo $admin[119]; ?></a> | <a href="?action=logout"><?php echo $admin[10];?></a></td></tr>
		<tr><td>
		
<?php
if($_GET['action']=='settings'){
	echo '<br /><h4>'.$admin[119].'</h4>';
?>

<?php
	switch($_GET['type']){
		case 'profile':
			include_once('interfaces/user/profile.php');
		break;
		case 'password':
			include_once('interfaces/user/password.php');
		break;
		case 'view_log':
			include_once('interfaces/user/view_log.php');
		break;
		case 'manage_block':
			include_once('interfaces/user/manage_block.php');
		break;
		default:
?>

		<table id="user_settings">
		<tr>
		<td><img src="images/identity.gif" alt="" /></td><td class="bold short"><a href="?action=settings&amp;type=profile"><?php echo $admin[120]; ?></a></td><td><?php echo $admin[121]; ?></td>
		</tr>
		<tr>
		<td><img src="images/password.gif" alt="" /></td><td class="bold short"><a href="?action=settings&amp;type=password"><?php echo $admin[65]; ?></a></td><td><?php echo $admin[123]; ?></td>
		</tr>
		<tr>
		<td><img src="images/manage.gif" alt="" /></td><td class="bold short"><a href="?action=settings&amp;type=manage_block"><?php echo $admin[124]; ?></a></td><td><?php echo $admin[125]; ?></td>
		</tr>
		<tr>
		<td><img src="images/view_log.gif" alt="" /></td><td class="bold short"><a href="?action=settings&amp;type=view_log"><?php echo $admin[67]; ?></a></td><td><?php echo $admin[162]; ?></td>
		</tr>		
		</table>

<?php
	}
}
else{
	//Load block view
	$crontab_list=$PLUGIN->get_blocks_array($_user_active['id']);
	if(count($crontab_list)>=1){
		$crontab_check=false;
		foreach($crontab_list as $block_selected){
		
			$block_info=$PLUGIN->get_block_settings($block_selected['block_id']);
			$plugin_info=$PLUGIN->get_plugin($block_info['plugin_id']);
			$block_info_text=unserialize($block_info['settings']);
			
			$iptables_settings=array();
			foreach($block_selected['iptables_id'] as $value_iptables){
				$ipt_tmp=$IPTABLES->get_iptables($value_iptables);
				$iptables_settings[]=array('name'=>$ipt_tmp['name'], 'name_web'=>$ipt_tmp['name_web'], 'color'=>$ipt_tmp['color'], 'other'=>$ipt_tmp['other']);
			}
		
			$crontab_lang=$_user_active['language'];
			//Load Plugin
			require('plugin/'.$plugin_info['folder'].'/index.php');
		}
	}
}
?>
		<br /><br /></td></tr>
		<tr><td id="menu_bottom">&nbsp;</td></tr>		
	</table>
	
	<div id="footer"><?php echo $PAGE->get_credits(); ?></div>
</div>

<?php
echo $PAGE->getFooter();
?>