<h4><?php echo $admin[8]; ?></h4>

<?php
switch($_GET['type']){
	case 'delete':
		if ($_POST['send']==$admin[33]){
			echo '<div class="submit_form">'.$PLUGIN->del_plugin($_GET['id']).'</div>';
		}
		elseif($_POST['send']==$admin[34]){
			echo '<div class="submit_form">'.$admin[101].'</div>';
		}
		else{
?>

<h5><?php echo $admin[94]; ?></h5>
<form method="post" action="">
<table id="delete_plugin" class="default_table">
<tr class="center"><td><input type="submit" name="send" value="<?php echo $admin[33]; ?>" /></td><td><input type="submit" name="send" value="<?php echo $admin[34]; ?>" /></td>
</tr></table>
</form>

<?php
		}
	break;
	case 'install':
		require_once('plugin/'.$_GET['name'].'/version.php');
		echo '<div class="submit_form">'.$PLUGIN->install_plugin($plugin).'</div>';
		unset($plugin);
	break;
	default:
?>

<table id="manage_plugin" class="default_table">
  <tr>
    <th><?php echo $admin[11]; ?></th>
    <th><?php echo $admin[50]; ?></th>
    <th><?php echo $admin[92]; ?></th>
    <th><?php echo $admin[93]; ?></th>
	<th><?php echo $admin[60]; ?></th>
  </tr>
<?php
	$new_plugin=$PLUGIN->get_new_plugin();
	foreach($new_plugin as $value){
		require_once('plugin/'.$value.'/version.php');
		echo '<tr><td>'.$plugin['name'].'</td><td>'.$plugin['description'].'</td><td>&nbsp;</td><td class="center">'.$plugin['version'].'</td><td><a href="?action=manage_plugin&amp;type=install&amp;name='.$plugin['folder'].'"><img src="images/install.png" alt="" title="'.$admin[132].'" /></a></td></tr>';
		unset($plugin);
	}

	$plugins_id=$PLUGIN->get_plugins_id();
	foreach($plugins_id as $value){
		$plugin_selected=$PLUGIN->get_plugin($value['id']);
		echo '<tr><td>'.$plugin_selected['name'].'</td><td>'.$plugin_selected['description'].'</td><td>'.$plugin_selected['date'].'</td><td class="center">'.$plugin_selected['version'].'</td><td>'.$PLUGIN->plugin_option_list($plugin_selected['id']).'</td></tr>';
	}
?>
</table>

<?php
}
?>