<?php
if ($_POST['send']==$admin[48]){
	$group_array=array('name'=>$_POST['name'], 'description'=>$_POST['description']);
	echo '<div class="submit_form">'.$GROUP->add_group($group_array).'</div>';
}
else{
?>

<h4><?php echo $admin[48]; ?></h4>
<form method="post" action="">
<table id="add_group" class="default_table">
  <tr>
    <td><?php echo $admin[11]; ?> * </td>
    <td><input type="text" name="name" /></td>
  </tr>
  <tr>
    <td><?php echo $admin[50]; ?></td>
    <td><textarea name="description" rows="" cols=""></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="send" value="<?php echo $admin[48]; ?>" /></td>
  </tr>
</table>
</form>
<br />
<div class="center">* <?php echo $admin[42]; ?></div>

<?php 
}
?>