<?php
if ($_POST['send']==$admin[26]){
		$user_array=array('username'=>$_POST['username'], 'passwd'=>$_POST['passwd'], 'privilege'=>$_POST['privilege'], 'name'=>$_POST['name'], 'surname'=>$_POST['surname'], 'phone'=>$_POST['phone'], 'fax'=>$_POST['fax'], 'mobile_phone'=>$_POST['mobile_phone'], 'email'=>$_POST['email'], 'language'=>$_POST['language'], 'city'=>$_POST['city'], 'nation'=>$_POST['nation'], 'place'=>$_POST['place'], 'zip_code'=>$_POST['zip_code'], 'address'=>$_POST['address'], 'group_id'=>$_POST['group_id'], 'account'=>$_POST['account']);
		
		echo '<div class="submit_form">'.$USER->add_user($user_array).'</div>';
}
else{
?>

<h4><?php echo $admin[5]; ?></h4>
<form method="post" action="">
<table id="add_user" class="default_table">
  <tr>
    <td><?php echo $admin[11]; ?> * </td>
    <td><input type="text" name="name" /></td>
  </tr>
  <tr>
    <td><?php echo $admin[12]; ?> * </td>
    <td><input type="text" name="surname" /></td>
  </tr>
  <tr>
    <td><?php echo $admin[13]; ?></td>
    <td><input type="text" name="nation" /></td>
  </tr>
  <tr>
    <td><?php echo $admin[14]; ?></td>
    <td><input type="text" name="city" /></td>
  </tr>
  <tr>
    <td><?php echo $admin[15]; ?></td>
    <td><input type="text" name="place" /></td>
  </tr>
  <tr>
    <td><?php echo $admin[16]; ?></td>
    <td><input type="text" name="zip_code" /></td>
  </tr>
  <tr>
    <td><?php echo $admin[17]; ?></td>
    <td><input type="text" name="address" /></td>
  </tr>
  <tr>
    <td><?php echo $admin[18]; ?></td>
    <td><input type="text" name="phone" /></td>
  </tr>
  <tr>
    <td><?php echo $admin[19]; ?></td>
    <td><input type="text" name="fax" /></td>
  </tr>
  <tr>
    <td><?php echo $admin[20]; ?></td>
    <td><input type="text" name="mobile_phone" /></td>
  </tr>
  <tr>
    <td><?php echo $admin[21]; ?> * </td>
    <td><input type="text" name="username" /></td>
  </tr>
  <tr>
    <td><?php echo $admin[22]; ?> * </td>
    <td><input type="text" name="passwd" /></td>
  </tr>
  <tr>
    <td><?php echo $admin[23]; ?> * </td>
    <td><input type="text" name="email" /></td>
  </tr>
  <tr>
    <td><?php echo $admin[24]; ?> * </td>
    <td><?php echo $LANGUAGE->languagesList(); ?></td>
  </tr>
  <tr>
    <td><?php echo $admin[55]; ?> * </td>
    <td><?php echo $GROUP->groups_list(); ?></td>
  </tr>
  <tr>
    <td><?php echo $admin[25]; ?> * </td>
    <td><?php echo $USER->privilege_list(); ?></td>
  </tr>
  <tr>
    <td><?php echo $admin[74]; ?> * </td>
    <td><?php echo $USER->account_list(ACTIVE); ?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="send" value="<?php echo $admin[26]; ?>" /></td>
  </tr>
</table>
</form>
<br />
<div class="center">* <?php echo $admin[42]; ?><br />
** <?php echo $admin[43]; ?></div>

<?php 
}
?>