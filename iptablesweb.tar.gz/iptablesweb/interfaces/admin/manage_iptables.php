<h4><?php echo $admin[97]; ?></h4>
<script type="text/javascript" src="js/picker.js"></script>

<?php
switch($_GET['type']){
	case 'configure':
	
		if ($_POST['send']==$admin[35]){
			$iptables_array=array('id'=>$_GET['id'], 'name'=>$_POST['name'], 'color'=>$_POST['color'], 'name_web'=>$_POST['name_web']);
			echo '<div class="submit_form">'.$IPTABLES->set_iptables($iptables_array).'</div>';
		}
		else{
?>

<h5><?php echo $admin[79]; ?></h5>
<?php
$iptables_selected=$IPTABLES->get_iptables($_GET['id']);
?>
<form method="post" action="" id="iptables_rules">
<table id="change_group" class="default_table">
  <tr>
    <td><?php echo $admin[98]; ?> * </td>
    <td><input type="text" name="name" value="<?php echo htmlspecialchars($iptables_selected['name']); ?>" /></td>
  </tr>
  <tr>
    <td><?php echo $admin[99]; ?> * </td>
    <td><input type="text" name="color" value="<?php echo htmlspecialchars($iptables_selected['color']); ?>" /> <a href="javascript:TCP.popup(document.forms['iptables_rules'].elements['color'])"><img alt="" title="" src="images/sel.gif" /></a></td>
  </tr>
  <tr>
    <td><?php echo $admin[11]; ?> * </td>
    <td><input type="text" name="name_web" value="<?php echo htmlspecialchars($iptables_selected['name_web']); ?>" /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="send" value="<?php echo $admin[35]; ?>" /></td>
  </tr>
</table>
</form>

<?php
		}
	break;
	case 'delete':
		if ($_POST['send']==$admin[33]){
			echo '<div class="submit_form">'.$IPTABLES->del_iptables($_GET['id']).'</div>';
		}
		elseif($_POST['send']==$admin[34]){
			echo '<div class="submit_form">'.$admin[101].'</div>';
		}
		else{
?>

<h5><?php echo $admin[69]; ?></h5>
<form method="post" action="">
<table id="delete_iptables" class="default_table">
<tr class="center"><td><input type="submit" name="send" value="<?php echo $admin[33]; ?>" /></td><td><input type="submit" name="send" value="<?php echo $admin[34]; ?>" /></td>
</tr></table>
</form>

<?php
		}
	break;
	default:

		if ($_POST['send']==$admin[103]){
				$iptables_array=array('name'=>$_POST['name'], 'color'=>$_POST['color'], 'name_web'=>$_POST['name_web']);
				
				echo '<div class="submit_form">'.$IPTABLES->add_iptables($iptables_array).'</div>';
		}
		else{
?>

<table id="manage_iptables" class="default_table">
  <tr>
    <th><?php echo $admin[98]; ?></th>
    <th><?php echo $admin[99]; ?></th>
    <th><?php echo $admin[11]; ?></th>
    <th><?php echo $admin[60]; ?></th>
  </tr>
<?php
	$iptables_id=$IPTABLES->get_iptables_id();
	foreach($iptables_id as $value){
		$iptables_selected=$IPTABLES->get_iptables($value['id']);
		echo '<tr><td>'.htmlspecialchars($iptables_selected['name']).'</td><td>'.$iptables_selected['color'].'</td><td>'.htmlspecialchars($iptables_selected['name_web']).'</td><td>'.$IPTABLES->option_list($iptables_selected['id']).'</td></tr>';
	}
?>
</table>

<br /><br />

<form method="post" id="iptables_rules" action="">
<table id="add_iptables" class="default_table">
<tr class="left"><td><?php echo $admin[98]; ?> * </td><td><input type="text" name="name" value="" /></td></tr>
<tr class="left"><td><?php echo $admin[99]; ?> * </td><td><input type="text" name="color" value="" /> <a href="javascript:TCP.popup(document.forms['iptables_rules'].elements['color'])"><img alt="" title="" src="images/sel.gif" /></a></td></tr>
<tr class="left"><td><?php echo $admin[11]; ?> * </td><td><input type="text" name="name_web" value="" /></td></tr>
<tr class="center"><td colspan="2"><br /><input type="submit" name="send" value="<?php echo $admin[103]; ?>" /></td></tr>
</table>
</form>

<?php
		}
}
?>