<h4><?php echo $admin[96]; ?></h4>

<script type="text/javascript" src="js/prototype.js"></script>
<script type="text/javascript" src="js/scriptaculous.js"></script>

<?php
$block_list = $PLUGIN->get_block_order('public');
?>

<ul id="block_list" class="sortable-list">
<?php
foreach ($block_list as $block_id => $title){
	$block_selected=$PLUGIN->get_block_settings($block_id);
	$plugin_selected=$PLUGIN->get_plugin($block_selected['plugin_id']);
?>
	<li id="block_<?php echo $block_id; ?>">
	<?php
	echo $title['name'];
	echo '<div class="small"><span class="bold">'.$admin[50].': </span>'.$title['description'].'</div>';
	echo '<div class="small"><span class="bold">'.$admin[106].': </span>'.htmlspecialchars($plugin_selected['name']).'</div>';
	echo '<div class="small"><span class="bold">'.$admin[105].': </span>';
	$iptables_list=$PLUGIN->get_iptables_list($block_id);	
	foreach($iptables_list as $iptables_id){
		$iptables_array=$IPTABLES->get_iptables($iptables_id);
		echo htmlspecialchars($iptables_array['name']).' ';
	}
	echo '</div>';

	?>
	</li>
<?php
}
?>
</ul>

<script type="text/javascript">
function updateOrder(){
	var handlerFunc = function(t){
		alert(t.responseText);
	}

	var errFunc = function(t) {
		alert('Error ' + t.status + ' -- ' + t.statusText);
	}

	var options ={
		method : 'post',
		parameters : 'user_id=<?php echo base64_encode('public'); ?>&' + Sortable.serialize('block_list'),
		onComplete:function(request){new Effect.Highlight('block_list',{startcolor:'#FFCCCD', endcolor:'#FFFFFF'})}
	};
	new Ajax.Request('processor.php', options);
}

Sortable.create('block_list', { onUpdate : updateOrder, ghosting:false,constraint:false });
</script>