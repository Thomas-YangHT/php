<?
if (filesize('includes/session_settings.php')<=0){
	header("Refresh: 0;URL=install.php");
	exit();
}
?>