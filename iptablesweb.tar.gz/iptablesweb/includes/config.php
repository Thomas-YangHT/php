<?php
//Include files
require_once('includes/connection_settings.php');
require_once('includes/session_settings.php');
require_once('includes/path_settings.php');

//Class files
require_once('classes/adodb/adodb.inc.php');
require_once('classes/session_class.php');
require_once('classes/page_class.php');
require_once('classes/mailer_class.php');
require_once('classes/utility_class.php');
require_once('classes/group_class.php');
require_once('classes/user_class.php');
require_once('classes/language_class.php');
require_once('classes/setting_class.php');
require_once('classes/plugin_class.php');
require_once('classes/iptables_class.php');
require_once('classes/system_info_class.php');
require_once('classes/phplot/phplot.php');

//Do not change
define('AUTH_NOT_LOGGED', 0);
define('AUTH_FAILED', 1);
define('AUTH_LOGGED', 2);
define('ACTIVE',1);
define('NOACTIVE',0);
define('ADMIN',2);
define('USER',1);
define('GUEST',0);
define('GUEST_BLOCK',-1);
define('USER_GUEST',-1);
define('EXTERNAL_STMP',1);
define('LOCAL_STMP',0);
define('SMTP_AUTH_YES',true);
define('SMTP_AUTH_NO',false);

//Advanced features
define('DB_PREFIX',"IPT_");
define('OPTIMIZE_DAY',10);

//Create object
$DB = NewADOConnection($_type_of_db_server);
$_res_db = @$DB->Connect($_host, $_user, $_password, $_db_name);
if (!$_res_db){
	exit('Database problem! Check your configuration');
}
$SESSION = new ipt_session($_session_time, $_session_gc_time, &$DB);
$PLUGIN = new plugin(&$DB);
$PAGE = new page();
$UTILITY = new utility();
$SETTING = new setting(&$DB);
$settings_mail=serialize(array('url'=>$SETTING->get_value('url')));
$MAILER = new mailer($settings_mail);
$GROUP = new group(&$DB);
$USER = new user(&$DB);
$LANGUAGE = new language();
$IPTABLES = new iptables(&$DB);
$SYSTEM_INFO = new system_info();

//Load GeoIP Object
include_once("classes/geoip.php");

//Error reporting
error_reporting(E_ALL ^ E_NOTICE);

//Logout
if ($_GET['action']=='logout'){
	$SESSION->logout();
}

//Check if session is active
list($_status, $_user_active) = $SESSION->auth_get_status();

//Define mail settings
if ($SETTING->get_value('send_mail_type')==EXTERNAL_STMP){
	$MAILER->IsSMTP();
	$MAILER->Host = $SETTING->get_value('mail_server');
	if($SETTING->get_value('mail_auth')){
		$MAILER->SMTPAuth = true;
		$MAILER->Username = $SETTING->get_value('mail_username');
		$MAILER->Password = $SETTING->get_value('mail_password');
	}
}
?>