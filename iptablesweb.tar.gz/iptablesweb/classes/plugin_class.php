<?php
//Plugin class
class plugin{

	var $DB;

	//Constructor
	function plugin($DB){
		$this->DB = $DB;
	}
	
	//Check if a plugin exists
	function exist_plugin($id){
		$id=(int)$id;
		$row = $this->DB->GetRow("SELECT * FROM `".DB_PREFIX."plugins` WHERE `id`='$id'");
		$tot=count($row);
		if ($tot>0){
			return true;
		}
		else{
			return false;
		}
	}
	
	//Check if a plugin folder exists
	function exist_plugin_folder($folder){
		$row = $this->DB->GetRow("SELECT * FROM `".DB_PREFIX."plugins` WHERE `folder`='$folder'");
		$tot=count($row);
		if ($tot>0){
			return true;
		}
		else{
			return false;
		}
	}

	//Get plugin info
	function get_plugin($id){
		$id=(int)$id;
		if ($this->exist_plugin($id)){
			return $this->DB->GetRow("SELECT * FROM `".DB_PREFIX."plugins` WHERE `id`='$id'");
		}
		//exit('Plugin doesn\'t exist (get_plugin)');
		return NULL;
	}
	
	//Get id of all plugin
	function get_plugins_id(){
		$plugins=array();
		$rs = & $this->DB->Execute("SELECT `id` FROM `".DB_PREFIX."plugins` ORDER BY `id` ASC");
		while (!$rs->EOF){
			$plugins[]=$rs->fields;
			$rs->MoveNext();
		}
		return $plugins;
	}
	
	//Install new plugin
	function install_plugin($plugin_array){
		if (!$this->exist_plugin_folder($plugin_array['folder'])){
			if (file_exists('plugin/'.$plugin_array['folder'].'/version.php')){
				$this->DB->Execute("INSERT INTO `".DB_PREFIX."plugins` (`date`,`folder`,`version`,`name`,`description`) VALUES (NOW(), '".$plugin_array['folder']."', '".$plugin_array['version']."', '".$plugin_array['name']."', '".$plugin_array['description']."')");
				return $GLOBALS['admin'][133];
			}
		}
		return 'Error plugin install';
	}
	
	//Get new plugin list
	function get_new_plugin(){
		$new_plugin=array();
		if ($handle = @opendir('plugin/')) {
			while (false !== ($folder = readdir($handle))) { 
				if ($folder!='.' && $folder!='..' && is_dir('plugin/'.$folder)){
					$row=$this->DB->GetRow("SELECT * FROM `".DB_PREFIX."plugins` WHERE `folder`='$folder'");
					if (!count($row)>0){
						$new_plugin[]=$folder;
					}
				}
			}
			closedir($handle); 
		}
		return $new_plugin;
	}
	
	//Delete plugin
	function del_plugin($id){
		$id=(int)$id;
		if ($this->exist_plugin($id)){

			$rs = & $this->DB->Execute("SELECT DISTINCT `id` FROM `".DB_PREFIX."block_settings` WHERE `plugin_id`='$id'");

			while (!$rs->EOF){
				$tmp_block=$rs->fields;
				$this->del_block($tmp_block['id']);
				$rs->MoveNext();
			}

			$this->DB->Execute("DELETE FROM `".DB_PREFIX."block_settings` WHERE `plugin_id`='$id'");
			$this->DB->Execute("DELETE FROM `".DB_PREFIX."plugins` WHERE `id`='$id'");
			$row=$this->DB->GetRow("SELECT * FROM `".DB_PREFIX."plugins`");
			if (!count($row)>0){
				$this->DB->Execute("DELETE FROM `".DB_PREFIX."block_iptables`");
				$this->DB->Execute("DELETE FROM `".DB_PREFIX."block_settings`");
				$this->DB->Execute("DELETE FROM `".DB_PREFIX."block_groups`");
				$this->DB->Execute("DELETE FROM `".DB_PREFIX."user_blocks`");
			}
			
			return $GLOBALS['admin'][100];
		}
		else{
			return 'Plugin doesn\'t exist (del_plugin)';
		}
	}
	
	//Check if a block exists
	function exist_block($id){
		$id=(int)$id;
		$row = $this->DB->GetRow("SELECT * FROM `".DB_PREFIX."block_settings` WHERE `id`='$id'");
		$tot=count($row);
		if ($tot>0){
			return true;
		}
		else{
			return false;
		}
	}
	
	//Get last block id
	function get_last_block_id(){
		$row=$this->DB->GetRow("SELECT `id` FROM `".DB_PREFIX."block_settings` ORDER BY `id` DESC LIMIT 0,1");
		return $row['id'];
	}
	
	//Get block not again installed
	function get_block_to_install($user_id){
		$block_to_install=array();
		$USER_TMP = new user(&$this->DB);
		if($USER_TMP->exist_user($user_id)){
			$user_row=$USER_TMP->get_user($user_id);	
			$rs = & $this->DB->Execute("SELECT `block_id` FROM `".DB_PREFIX."block_groups` WHERE `group_id`='".$user_row['group_id']."'");
			while (!$rs->EOF){
				$tmp_block=$rs->fields;
				$block_installed=$this->DB->GetRow("SELECT `block_id` FROM `".DB_PREFIX."user_blocks` WHERE `block_id`='".$tmp_block['block_id']."' AND `user_id`='".$user_id."'");
				if(!count($block_installed)>0){
					$block_to_install[]=$tmp_block['block_id'];
				}
				$rs->MoveNext();
			}
		}
		return $block_to_install;
	}
		
	//Add new block
	function add_block($block_array){
		$block_array_tmp=unserialize($block_array['var_serialized']);
		if ($block_array['plugin_list']=='' || count($block_array['iptables'])<=0 || $block_array_tmp['name']==''){
			return $GLOBALS['admin'][44];
		}
		
		if ($block_array['public']!=ACTIVE && count($block_array['groups'])<=0){
			return $GLOBALS['admin'][95];
		}
		
		$this->DB->Execute("INSERT INTO `".DB_PREFIX."block_settings` (`plugin_id`, `settings`) VALUES ('".$block_array['plugin_list']."', '".$block_array['var_serialized']."')");
		$block_id=$this->get_last_block_id();
		
		foreach ($block_array['iptables'] as $value){
			$this->DB->Execute("INSERT INTO `".DB_PREFIX."block_iptables` (`block_id`, `iptables_id`) VALUES ('".$block_id."', '".$value."')");
		}
		
		if (count($block_array['groups'])>0){
			foreach ($block_array['groups'] as $value){
				$this->DB->Execute("INSERT INTO `".DB_PREFIX."block_groups` (`block_id`, `group_id`) VALUES ('".$block_id."', '".$value."')");
			}
		}
		
		if ($block_array['public']==1){
			$this->DB->Execute("INSERT INTO `".DB_PREFIX."block_groups` (`block_id`, `group_id`) VALUES ('".$block_id."', '".GUEST_BLOCK."')");
			$this->DB->Execute("INSERT INTO `".DB_PREFIX."user_blocks` (`block_id`, `user_id`) VALUES ('".$block_id."', '".GUEST_BLOCK."')");
		}
		
		return $GLOBALS['admin'][109];
	}
	
	//Install block_id to user_id
	function install_block($user_id, $block_id){
		$user_id=(int)$user_id;
		$block_id=(int)$block_id;
		if ($this->exist_block($block_id)){
			@$this->DB->Execute("INSERT INTO `".DB_PREFIX."user_blocks` (`block_id`, `user_id`) VALUES ('".$block_id."', '".$user_id."')");
			return $GLOBALS['admin'][135];
		}
		return $GLOBALS['admin'][136];
	}
	
	//Uninstall block_id to user_id
	function uninstall_block($user_id, $block_id){
		$user_id=(int)$user_id;
		$block_id=(int)$block_id;
		if ($this->exist_block($block_id)){
			@$this->DB->Execute("DELETE FROM `".DB_PREFIX."user_blocks` WHERE `block_id`='".$block_id."' AND `user_id`='".$user_id."'");
			return $GLOBALS['admin'][137];
		}
		return $GLOBALS['admin'][138];
	}
	
	//Set block settings
	function set_block($block_array){
		$block_array_tmp=unserialize($block_array['var_serialized']);
		if ($this->exist_block($block_array['id'])){
			if (count($block_array['iptables'])<=0 || $block_array_tmp['name']==''){
				return $GLOBALS['admin'][44];
			}
			if ($block_array['public']!=ACTIVE && count($block_array['groups'])<=0){
				return $GLOBALS['admin'][95];
			}
			
			$this->DB->Execute("UPDATE `".DB_PREFIX."block_settings` SET `settings`='".$block_array['var_serialized']."' WHERE `id`='".$block_array['id']."'");
			
			$this->DB->Execute("DELETE FROM `".DB_PREFIX."block_iptables` WHERE `block_id`='".$block_array['id']."'");
			foreach ($block_array['iptables'] as $value){
				$this->DB->Execute("INSERT INTO `".DB_PREFIX."block_iptables` (`block_id`, `iptables_id`) VALUES ('".$block_array['id']."', '".$value."')");
			}
			
			$this->DB->Execute("DELETE FROM `".DB_PREFIX."block_groups` WHERE `block_id`='".$block_array['id']."'");
			if (count($block_array['groups'])>0){
				foreach ($block_array['groups'] as $value){
					$this->DB->Execute("INSERT INTO `".DB_PREFIX."block_groups` (`block_id`, `group_id`) VALUES ('".$block_array['id']."', '".$value."')");
				}
			}
			
			$this->DB->Execute("DELETE FROM `".DB_PREFIX."user_blocks` WHERE `block_id`='".$block_array['id']."' AND `user_id`='".USER_GUEST."'");
			if ($block_array['public']==ACTIVE){
				$this->DB->Execute("INSERT INTO `".DB_PREFIX."block_groups` (`block_id`, `group_id`) VALUES ('".$block_array['id']."', '".GUEST_BLOCK."')");
				$this->DB->Execute("INSERT INTO `".DB_PREFIX."user_blocks` (`block_id`, `user_id`) VALUES ('".$block_array['id']."', '".USER_GUEST."')");
			}
			return $GLOBALS['admin'][59];

		}
		return 'Block not present';
	
	}
	
	//Get block settings
	function get_block_settings($id){
		$id=(int)$id;
		if ($this->exist_block($id)){
			return $this->DB->GetRow("SELECT * FROM `".DB_PREFIX."block_settings` WHERE `id`='$id'");
		}
		exit('Block doesn\'t exist (get_block_settings)');
	}
	
	//Get id of all block. $privilege=public only public groups, $privilege=user only user groups, $privilege=all all groups
	function get_blocks_id($privilege){
		$block=array();
		if ($privilege=='user'){
			$rs = & $this->DB->Execute("SELECT DISTINCT `block_id` FROM `".DB_PREFIX."block_groups` WHERE `group_id`='".GUEST_BLOCK."' ORDER BY `group_id`");
		}
		elseif ($privilege=='public'){
			$rs = & $this->DB->Execute("SELECT DISTINCT `block_id` FROM `".DB_PREFIX."block_groups` WHERE `group_id`!='".GUEST_BLOCK."' ORDER BY `group_id`");
		}
		else{
			$rs = & $this->DB->Execute("SELECT DISTINCT `block_id` FROM `".DB_PREFIX."block_groups` ORDER BY `group_id`");
		}
		$tmp_block='';
		while (!$rs->EOF){
			$tmp_block=$rs->fields;
			$block[]=$tmp_block['block_id'];
			$rs->MoveNext();
		}
		return $block;
	}
	
	//Delete block
	function del_block($id){
		$id=(int)$id;
		if ($this->exist_block($id)){
			$this->DB->Execute("DELETE FROM `".DB_PREFIX."block_settings` WHERE `id`='$id'");
			$this->DB->Execute("DELETE FROM `".DB_PREFIX."block_iptables` WHERE `block_id`='$id'");
			$this->DB->Execute("DELETE FROM `".DB_PREFIX."block_groups` WHERE `block_id`='$id'");
			$this->DB->Execute("DELETE FROM `".DB_PREFIX."user_blocks` WHERE `block_id`='$id'");
			return $GLOBALS['admin'][100];
		}
		return 'Block doesn\'t exist (del_block)';
	}
	
	//Get the block order. (Used by AJAX) $privilege=public only public groups, $privilege=user only user groups, $privilege=all all groups, is_numeric($privilege)=privilege of user_id
	function get_block_order($privilege){
		$block_list = array();
		if ($privilege=='public'){
			$rs = & $this->DB->Execute("SELECT * FROM `".DB_PREFIX."user_blocks` WHERE `user_id`='".GUEST_BLOCK."' ORDER BY `ranking`");
		}
		elseif ($privilege=='user'){
			$rs = & $this->DB->Execute("SELECT * FROM `".DB_PREFIX."user_blocks` WHERE `user_id`!='".GUEST_BLOCK."' ORDER BY `ranking`");
		}
		elseif($privilege>=0){
			$rs = & $this->DB->Execute("SELECT * FROM `".DB_PREFIX."user_blocks` WHERE `user_id`='".$privilege."' ORDER BY `ranking`");
		}
		else{
			$rs = & $this->DB->Execute("SELECT * FROM `".DB_PREFIX."user_blocks` ORDER BY `ranking`");
		}
		while (!$rs->EOF) {
			$user_block=$rs->fields;
			$block_selected=$this->get_block_settings($user_block['block_id']);
			$settings=unserialize($block_selected['settings']);
			$block_list[$block_selected['id']] = $settings;
			$rs->MoveNext();
		}
		return $block_list;
	}
	

	//Update block list order. (Used by AJAX) $privilege=public only public groups, $privilege=user only user groups, $privilege=all all groups, $privilege>=1 user_id
    function set_block_order($key, $privilege){
		if (!isset($_POST[$key]) || !is_array($_POST[$key]) || $privilege==''){
			return;
		}
		
		$plugin_list = $this->get_block_order($privilege);
		$queries = array();
		$ranking = 1;
		
		foreach ($_POST[$key] as $id){
			if (!array_key_exists($id, $plugin_list))
				continue;
	
			$ranking_tmp=(int)$ranking;
			$id_tmp=(int)$id;

			if($privilege=='public'){
				$query = "UPDATE `".DB_PREFIX."user_blocks` SET `ranking` = '$ranking_tmp' WHERE `block_id` = '$id_tmp' AND `user_id`='".GUEST_BLOCK."'";
			}
			elseif($privilege=='user'){
				$query = "UPDATE `".DB_PREFIX."user_blocks` SET `ranking` = '$ranking_tmp' WHERE `block_id` = '$id_tmp' AND `user_id`!='".GUEST_BLOCK."'";
			}
			elseif($privilege>=0){
				$query = "UPDATE `".DB_PREFIX."user_blocks` SET `ranking` = '$ranking_tmp' WHERE `block_id` = '$id_tmp' AND `user_id`='$privilege'";
			}		
			else{
				$query = "UPDATE `".DB_PREFIX."user_blocks` SET `ranking` = '$ranking_tmp'";
			}	

			$this->DB->Execute($query);
			$ranking++;
		}
    }
	
	//Get plugin option list
	function plugin_option_list($id){
		$id=(int)$id;
		if ($this->exist_plugin($id)){
			$buffer='<a href="admin.php?action=manage_plugin&amp;type=delete&amp;id='.$id.'"><img src="images/delete.png" alt="'.$GLOBALS['admin'][80].'" title="'.$GLOBALS['admin'][80].'" /></a>';
			return $buffer;
		}
		return 'Plugin doesn\'t exist (plugin_option_list)';
	}
	
	//Get plugin select
	function get_plugin_select(){
		$buffer='<select name="plugin_list" onchange="javascript:setMicrocat(this);"><option value="">'.$GLOBALS['admin'][144].'</option>';
		$plugins_id=$this->get_plugins_id();
		foreach ($plugins_id as $value){
			$plugin_selected=$this->get_plugin($value['id']);
			$buffer.='<option value="'.$plugin_selected['id'].'">'.$plugin_selected['name'].'</option>';
		}
		$buffer.='</select>';
		return $buffer;
	}
	
	//Get id list of iptables, in a block
	function get_iptables_list($block_id){
		$block_id=(int)$block_id;
		if ($this->exist_block($block_id)){
			$rs=$this->DB->Execute("SELECT `iptables_id` FROM `".DB_PREFIX."block_iptables` WHERE `block_id`='$block_id'");
			$iptables_list=array();
			while (!$rs->EOF) {
				$iptables_array=$rs->fields;
				$iptables_list[] = $iptables_array['iptables_id'];
				$rs->MoveNext();
			}
			return $iptables_list;
		}
		exit('Block doesn\'t exist (get_iptables_list)');
	}
	
	//Get id list of group. $privilege=public only public groups, $privilege=user only user groups, $privilege=all all groups
	function get_group_list($block_id, $privilege){
		$block_id=(int)$block_id;
		if ($privilege=='user'){
			$rs=$this->DB->Execute("SELECT `group_id` FROM `".DB_PREFIX."block_groups` WHERE `block_id`='$block_id' AND `group_id`='".GUEST_BLOCK."'");
		}
		elseif ($privilege=='public'){
			$rs=$this->DB->Execute("SELECT `group_id` FROM `".DB_PREFIX."block_groups` WHERE `block_id`='$block_id' AND `group_id`!='".GUEST_BLOCK."'");
		}
		else{
			$rs=$this->DB->Execute("SELECT `group_id` FROM `".DB_PREFIX."block_groups` WHERE `block_id`='$block_id'");
		}
		$group_list=array();
		while (!$rs->EOF) {
			$group_array=$rs->fields;
			$group_list[] = $group_array['group_id'];
			$rs->MoveNext();
		}
		return $group_list;
	}
	
	//Get block option list
	function block_option_list($id){
		$id=(int)$id;
		if ($this->exist_block($id)){
			$buffer='<a href="admin.php?action=manage_block&amp;type=configure&amp;id='.$id.'"><img src="images/configure.png" alt="'.$GLOBALS['admin'][110].'" title="'.$GLOBALS['admin'][110].'" /></a> <a href="admin.php?action=manage_block&amp;type=delete&amp;id='.$id.'"><img src="images/delete.png" alt="'.$GLOBALS['admin'][52].'" title="'.$GLOBALS['admin'][52].'" /></a>';
			return $buffer;
		}
		return 'Block doesn\'t exist (block_option_list)';
	}
	
	//Check if a block is public
	function is_public_block($block_id){
		$block_id=(int)$block_id;
		$row = $this->DB->GetRow("SELECT `block_id` FROM `".DB_PREFIX."block_groups` WHERE `block_id`='$block_id' AND `group_id`='".GUEST_BLOCK."'");
		$tot=count($row);
		if ($tot>0){
			return ACTIVE;
		}
		else{
			return NOACTIVE;
		}
	}
	
	//Check if a block is public
	function is_public_block_text($block_id){
		$block_id=(int)$block_id;
		if ($this->is_public_block($block_id)==ACTIVE){
			return $GLOBALS['admin'][33];
		}
		else{
			return $GLOBALS['admin'][34];
		}
	}
	
	//Get public list
	function account_list($block_id=false){
		$block_id=(int)$block_id;
		$public_array=$this->get_public_array();
		$buffer='<select name="public">';
		$is_public='';
		if ($block_id!=false){
			$is_public=$this->is_public_block($block_id);
		}
		
		foreach ($public_array as $key => $value){
			if ($is_public==$value['id'] && $block_id!=''){
				$buffer.='<option selected="selected" value="'.$value['id'].'">'.$value['name'].'</option>';
			}
			else{
				$buffer.='<option value="'.$value['id'].'">'.$value['name'].'</option>';
			}
		}
		$buffer.='</select>';
		return $buffer;
	}
	
	//Get public array
	function get_public_array(){
		return array(array('id'=>ACTIVE, 'name'=>$GLOBALS['admin'][33]), array('id'=>NOACTIVE, 'name'=>$GLOBALS['admin'][34]));
	}
	
	//Get blocks array (for crontab script and block view)
	function get_blocks_array($user_id=false){
		if ($user_id==false){
			$rs=$this->DB->Execute("SELECT DISTINCT `block_id` FROM `".DB_PREFIX."block_groups`");
		}
		else{
			//$rs=$this->DB->Execute("SELECT DISTINCT bg.block_id FROM `".DB_PREFIX."block_groups` AS bg, `".DB_PREFIX."user_blocks` AS ub WHERE ub.user_id='7' ORDER BY ub.ranking DESC");
			$rs=$this->DB->Execute("SELECT `block_id` FROM `".DB_PREFIX."user_blocks` WHERE `user_id`='$user_id' ORDER BY ranking ASC");
		}
		$block_array=array();
		while (!$rs->EOF) {
			$block_array=$rs->fields;

	/*		$rs1=$this->DB->Execute("SELECT `group_id` FROM `".DB_PREFIX."block_groups` WHERE `block_id`='".$block_array['block_id']."'");
			$group_array=array();
			while (!$rs1->EOF) {
				$group_info=$rs1->fields;
				$group_array[]=$group_info['group_id'];
				$rs1->MoveNext();
			}
		*/	
			$iptables_info=$this->get_iptables_list($block_array['block_id']);

			//$groups_array[]=array('block_id'=>$block_array['block_id'], 'groups_id'=>$group_array, 'iptables_id'=>$iptables_info);
			$groups_array[]=array('block_id'=>$block_array['block_id'], 'iptables_id'=>$iptables_info);
			$rs->MoveNext();
		}
		return $groups_array;
	}

}
?>