<?php
//Iptables class
class iptables{

	var $DB;

	//Constructor
	function iptables($DB){
		$this->DB = $DB;
	}

	//Check if a iptables id exists
	function exist_iptables($id){
		$id=(int)$id;
		$row = $this->DB->Execute("SELECT `id` FROM `".DB_PREFIX."iptables_variables` WHERE `id`='$id'");
		$tot=count($row);
		if ($tot>0){
			return true;
		}
		else{
			return false;
		}
	}
	
	//Check if a iptables prefix exists
	function exist_iptables_prefix($name){
		$row = $this->DB->Execute("SELECT `id` FROM `".DB_PREFIX."iptables_variables` WHERE `prefix`='$name'");
		$tot=count($row);
		if ($tot>0){
			return true;
		}
		else{
			return false;
		}
	}
	
	//Get iptables rule info
	function get_iptables($id){
		$id=(int)$id;
		if ($this->exist_iptables($id)){
			return $this->DB->GetRow("SELECT * FROM `".DB_PREFIX."iptables_variables` WHERE `id`='$id'");
		}
		exit('Iptables doesn\'t exist (get_iptables)');		
	}
	
	//Set iptables rule
	function set_iptables($iptables_array){
		if ($this->exist_iptables($iptables_array['id'])){
			if ($iptables_array['name']=='' || $iptables_array['color']=='' || $iptables_array['name_web']==''){
				return $GLOBALS['admin'][44];
			}
			$this->DB->Execute("UPDATE `".DB_PREFIX."iptables_variables` SET `name`='".$iptables_array['name']."', `color`='".$iptables_array['color']."', `name_web`='".$iptables_array['name_web']."' WHERE `id`='".$iptables_array['id']."'");
			return $GLOBALS['admin'][59];
		}
		return 'Iptables rule doesn\'t exist (set_iptables)';
	}
	
	//Add iptables rule
	function add_iptables($iptables_array){
		if ($iptables_array['name']==''){
			return $GLOBALS['admin'][44];
		}
		$this->DB->Execute("CREATE TABLE `".$iptables_array['name']."` (`timelog` int(10) unsigned NOT NULL default '0', `countlog` int(10) NOT NULL default '0', PRIMARY KEY  (`timelog`))");
		
		$this->DB->Execute("INSERT INTO `".DB_PREFIX."iptables_variables` (`name`, `color`, `name_web`) VALUES ('".$iptables_array['name']."', '".$iptables_array['color']."', '".$iptables_array['name_web']."')");
		return $GLOBALS['admin'][102];
	}	
	
	//Get id of all iptables rules
	function get_iptables_id(){
		$iptables=array();
		$rs = & $this->DB->Execute("SELECT `id` FROM `".DB_PREFIX."iptables_variables`");
		while (!$rs->EOF){
			$iptables[]=$rs->fields;
			$rs->MoveNext();
		}
		return $iptables;
	}
	
	//Delete iptables rule
	function del_iptables($id){
		$id=(int)$id;
		if ($this->exist_iptables($id)){
			$iptables_selected=$this->get_iptables($id);
			$this->DB->Execute("DROP TABLE `".$iptables_selected['name']."`");
			$this->DB->Execute("DELETE FROM `".DB_PREFIX."iptables_variables` WHERE `id`='$id'");
			$this->DB->Execute("DELETE FROM `".DB_PREFIX."block_iptables` WHERE `iptables_id`='$id'");
			$row=$this->DB->GetRow("SELECT * FROM `".DB_PREFIX."iptables_variables`");
			if (!count($row)>0){
				$this->DB->Execute("DELETE FROM `".DB_PREFIX."block_iptables`");
				$this->DB->Execute("DELETE FROM `".DB_PREFIX."block_settings`");
				$this->DB->Execute("DELETE FROM `".DB_PREFIX."block_groups`");
				$this->DB->Execute("DELETE FROM `".DB_PREFIX."user_blocks`");
			}
			return $GLOBALS['admin'][100];
		}
		else{
			return 'Iptablesweb rule doesn\'t exist (del_iptables)';
		}
	}
	
	//Get option list
	function option_list($id){
		$id=(int)$id;
		if ($this->exist_iptables($id)){
			$buffer='<a href="admin.php?action=manage_iptables&amp;type=configure&amp;id='.$id.'"><img src="images/configure.png" alt="'.$GLOBALS['admin'][79].'" title="'.$GLOBALS['admin'][79].'" /></a> <a href="admin.php?action=manage_iptables&amp;type=delete&amp;id='.$id.'"><img src="images/delete.png" alt="'.$GLOBALS['admin'][80].'" title="'.$GLOBALS['admin'][80].'" /></a>';
			return $buffer;
		}
		return 'Iptablesweb rule doesn\'t exist (option_list)';
	}
	
	//Get iptables rule checkbox
	function get_iptables_checkbox($array_rule=false){
		$buffer='';
		$iptables_id=$this->get_iptables_id();
		foreach ($iptables_id as $value){
			$iptables_selected=$this->get_iptables($value['id']);
			$tmp_checkbox='';
			if ($array_rule!=false){
				foreach ($array_rule as $value_rule){
					if ($value_rule==$iptables_selected['id']){
						$tmp_checkbox='checked="checked" ';
					}
				}
			}

			$buffer.='<input name="iptables[]" type="checkbox" class="no_width" value="'.$iptables_selected['id'].'" '.$tmp_checkbox.'/> '.$iptables_selected['name'].'<br />';
		}
		return $buffer;
	}
	
	//Get id from name of iptables rules
	function name2id($name){
		return $this->DB->GetRow("SELECT * FROM `".DB_PREFIX."iptables_variables` WHERE `name`='$name'");
	}

}
?>