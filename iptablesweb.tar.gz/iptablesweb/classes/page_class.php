<?php
//Class to make pages
class page{

	//Constructor
	function page(){}
	
	//Header
	function getHeader($interface, $title){
		$buffer='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="description" content="IptablesWeb - Inspect your iptables logs using a web browser!" />
<meta name="author" content="[Gnomix]" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="author" content="[Gnomix]" />
<meta name="copyright" content="Copyright (c) 2005-2006 IptablesWeb" />
<meta name="generator" content="IptablesWeb - http://iptablesweb.sourceforge.net" />
<link href="style/default.css" rel="stylesheet" type="text/css" />';

if (file_exists('style/'.$interface.'.css')){
	$buffer.="\n".'<link href="style/'.$interface.'.css" rel="stylesheet" type="text/css" />';
}

$buffer.='<title>'.$title.'</title>
<!--
******************************************************************
***** IptablesWeb - http://iptablesweb.sourceforge.net/ **********
******************************************************************
-->
</head>
<body>';
		return $buffer;
	}
	
	//Footer
	function getFooter(){
		$buffer='</body></html>';
		return $buffer;
	}
	
	//Get credits
	function get_credits(){
		return '<a href="http://www.php.net" onclick="window.open(this.href); return false;"><img src="images/php.png" alt="" /></a> <a href="http://www.w3.org/" onclick="window.open(this.href); return false;"><img src="images/css.gif" alt="" /></a> <a href="http://www.w3.org/" onclick="window.open(this.href); return false;"><img src="images/xhtml.gif" alt="" /></a><br /><br />
  <a href="http://iptablesweb.sourceforge.net" onclick="window.open(this.href); return false;">IptablesWeb&copy;</a> 2005-2006 [Gnomix]<br />All logos and trademarks in this site are property of their respective owner';
	}
	
}
?>