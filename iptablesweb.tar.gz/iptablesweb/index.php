<?php
require_once('includes/config.php');

list($_status, $_user_active) = $SESSION->auth_get_status();

//Load dictionary
$default_language=$SETTING->get_value('language');
$language_file='lang/'.$default_language.'/dictionary.php';
if (file_exists($language_file)){
	require_once($language_file);
}
else{
	exit('NO Dictionary!');
}

if($_status == AUTH_NOT_LOGGED && $_POST['send']==$admin[82]){
	$uname = $_POST['username'];
	$passw = $_POST['passwd'];
	if($uname == "" || $passw == ""){
		$_status = AUTH_FAILED;
	}else{
		list($_status, $_user_active) = $SESSION->login($uname, $passw);
	}
}

switch($_status){
	case AUTH_LOGGED:
		switch($_user_active['privilege']){
			case USER:
				$page_redirect='user.php';
			break;
			case ADMIN:
				$page_redirect='user.php';
			break;
		}
		header("Refresh: 1;URL=$page_redirect");
		echo $PAGE->getHeader('index',$admin[56]);
		echo '<div class="center">Loading...</div>';
		echo $PAGE->getFooter();
		exit();
	break;
}

if($SETTING->get_value('public')==1 && $_GET['action']!='login'){
	echo $PAGE->getHeader('public',$admin[41]);
?>
<div id="container">
	<table id="header"><tr>
	<td class="left"><?php echo $UTILITY->get_logo('index'); ?></td>
	<td class="right"><h3><?php echo $admin[142]; ?></h3><br /><div class="login_links"><a href="?action=login"><?php echo $admin[82]; ?></a><br /><a href="lost_password.php"><?php echo $admin[83]; ?></a></div></td>
	</tr></table>

	<table id="central">
		<tr><td id="menu">&nbsp;</td></tr>
		<tr><td>
<?php
//Load block view
$crontab_list=$PLUGIN->get_blocks_array('-1');
$crontab_check=false;
if(count($crontab_list)>=1){
	foreach($crontab_list as $block_selected){
	
		$block_info=$PLUGIN->get_block_settings($block_selected['block_id']);
		$plugin_info=$PLUGIN->get_plugin($block_info['plugin_id']);
		$block_info_text=unserialize($block_info['settings']);
		
		$iptables_settings=array();
		foreach($block_selected['iptables_id'] as $value_iptables){
			$ipt_tmp=$IPTABLES->get_iptables($value_iptables);
			$iptables_settings[]=array('name'=>$ipt_tmp['name'], 'name_web'=>$ipt_tmp['name_web'], 'color'=>$ipt_tmp['color'], 'other'=>$ipt_tmp['other']);
		}
	
		$crontab_lang=$SETTING->get_value('language');
		//Load Plugin
		require('plugin/'.$plugin_info['folder'].'/index.php');
	}
}
?>
		<br /><br /></td></tr>
		<tr><td id="menu_bottom">&nbsp;</td></tr>
	</table>
	
	<div id="footer"><?php echo $PAGE->get_credits(); ?></div>
</div>
<?
	echo $PAGE->getFooter();
	$link_logo='index.php';
}
else{
	echo $PAGE->getHeader('login',$admin[81]);
	$link_logo='index.php?action=login';
?>

<form method="post" action="">
  <table id="login">
	<tr><td colspan="2" class="center"><?php echo $UTILITY->get_logo($link_logo); ?></td></tr>
	<?php
	if ($_status==AUTH_FAILED){
		echo '<tr><td colspan="2"><span id="login_failed">'.$admin[90].'</span></td></tr>';
	}	
	?>
    <tr>
      <td><?php echo $admin[21]; ?></td><td><input type="text" name="username" /></td>
    </tr>
    <tr>
      <td><?php echo $admin[22]; ?></td><td><input type="password" name="passwd" /></td>
    </tr>
    <tr>
      <td>&nbsp;</td><td><input type="submit" name="send" value="<?php echo $admin[82]; ?>" /></td>
    </tr>
    <tr>
      <td colspan="2"><br /><a href="lost_password.php"><?php echo $admin['83']; ?></a></td>
    </tr>
  </table>
</form>

<?php
echo $PAGE->getFooter();
}
?>
